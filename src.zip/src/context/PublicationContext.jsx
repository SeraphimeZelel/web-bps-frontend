import React, { createContext, useState, useEffect } from "react";

const PublicationContext = createContext(null);

import cover1 from "../assets/cover1.webp";
import cover2 from "../assets/cover2.webp";
import cover3 from "../assets/cover3.webp";

const initialPublications = [
  {
    id: 1,
    title: "Statistik Aceh dalam Angka 2025",
    releaseDate: "2025-02-28",
    description: "Publikasi ini menyajikan data dan analisis...",
    coverUrl: cover1,
  },
  {
    id: 2,
    title: "Statistik Kesehatan Provinsi Aceh 2024",
    releaseDate: "2025-02-18",
    description: "Publikasi ini menyajikan data dan analisis...",
    coverUrl: cover2,
  },
  {
    id: 3,
    title: "Profil Kemiskinan Provinsi Aceh Tahun 2024",
    releaseDate: "2024-12-30",
    description: "Publikasi ini menyajikan data dan analisis..",
    coverUrl: cover3,
  },
];

const PublicationProvider = ({ children }) => {
  const [publications, setPublications] = useState(() => {
    const savedPublications = localStorage.getItem("publications");
    return savedPublications
      ? JSON.parse(savedPublications)
      : initialPublications;
  });

  useEffect(() => {
    localStorage.setItem("publications", JSON.stringify(publications));
  }, [publications]);

  const addPublication = (newPub) => {
    setPublications((prev) => [newPub, ...prev]);
  };

  const editPublication = (updatedPub) => {
    setPublications((prev) =>
      prev.map((pub) => (pub.id === updatedPub.id ? updatedPub : pub))
    );
  };

  const deletePublication = (id) => {
    setPublications((prev) => prev.filter((pub) => pub.id !== id));
  };
  return (
    <PublicationContext.Provider
      value={{
        publications,
        addPublication,
        editPublication,
        deletePublication,
      }}
    >
      {children}
    </PublicationContext.Provider>
  );
};
export { PublicationContext, PublicationProvider };
